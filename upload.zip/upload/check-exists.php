<?php

	//文件要存进的目录了解一下

	$targetFolder = '/uploads'; // 我在根目录建立的uploads目录

	$path = $_REQUEST['path'] ?? 'image';

	//你说什么不知道为啥用这个路径，如果实在不明白的话去问刚哥吧

	$checkPath = $_SERVER['DOCUMENT_ROOT'].$targetFolder.'/'.$path;

	//创建以后还得检查文件是否存在呢(该步骤也可以放到上传文件里面检测也是一样的，看你自己个人了，有这个文件比较活，想检撤检撤)

	$filename = $_REQUEST['filename'];
	
	if (file_exists($checkPath.'/'.$filename)) {  //其实就是检查该目录是否存在
		echo 1;
	} 

	echo 0;

?>