<?php

	$targetFolder = '/uploads/';

	$path = $_REQUEST['path'] ?? $path;

	$checkpath = $_SERVER['DOCUMENT_ROOT'].$targetFolder.$path;

	if (!file_exists($checkpath)) {

		mkdir($checkpath);
	}

	if (!isset($_FILES['Filedata'])) {

		echo '无效访问';

	} else {

		//获取后缀名

		$filename = $_FILES['Filedata']['name'];

		$ext = substr($filename, strrpos($filename, '.')); 

		$newfile = time() . rand() . $ext;

		$result = move_uploaded_file($_FILES['Filedata']['tmp_name'], $checkpath . '/' . $newfile);

		if ($result) {

			echo  $newfile;

		} else {

			echo 0;

		}

	}
?>

