<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>上传测试</title>
<script src="jquery.min.js" type="text/javascript"></script>
<script src="jquery.uploadifive.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="uploadifive.css">
<style type="text/css">
body {
	font: 13px Arial, Helvetica, Sans-serif;
}
/*.uploadifive-button {
	float: left;
	margin-right: 10px;
}
#queue {
	border: 1px solid #E5E5E5;
	height: 177px;
	overflow: auto;
	margin-bottom: 10px;
	padding: 0 3px 3px;
	width: 300px;
}*/
</style>
</head>

<body>
	<h1>上传demo</h1>
	<form>
		<div id="aaa"></div>
		<input id="file_upload" name="file_upload" type="file" >
	</form>
	<div id=""></div>
	<script type="text/javascript">
		//
		

		var imgs = '';

		$(function() {
			$('#file_upload').uploadifive({

				//是否开启自动上传(既时上传)

				'auto'             : true,

				//按钮上的文字
				'buttonText'       :'文件上传',

				//是否开启检撤文件(该名称文件)是否存在   //如果文件名称是自己生成的我想也没啥必要了（uploadfive文件里有自己生成的例子，仅供参考）

				'checkScript'      : 'check-exists.php',

				//限制文件类型          

				// 'fileType'         : 'image/jpeg',

				//带入的数据

				'formData'         : {
									   'path'      : 'abc11'
				                     },
				//上传时进度条位置id                     
				'queueID'          : 'aaa',

				//上传地址          这个文件可以自己写
				'uploadScript'     : 'uploadifive.php',

				//上传成功后返回值
				'onUploadComplete' : function(file, data) {
				
					if (data) {

						//这个例子是刚哥的想法，你们可以有别的操作
						// imgs += "<img src = 'uploads/abc11/"+data+"' width = '150'/>";

						// $("#aaa").html(imgs);

					} else {

						alert('上传失败');

						return false;
					}
				}
			});
		});
	</script>
</body>
</html>